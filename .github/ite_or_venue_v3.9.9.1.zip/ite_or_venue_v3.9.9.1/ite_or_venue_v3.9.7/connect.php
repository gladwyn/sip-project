<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<body>
	<?php
	//connection
	$conn = mysqli_connect("localhost","root","","ite_venue");
   //query for studentinfo 
    ?>
</body>
</html>